package com.example.gamesdb;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import org.json.JSONArray;
import org.json.JSONObject;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class GameApplication extends Application {

    private Scene mainScene;

    // Main entry point of the application
    @Override
    public void start(Stage primaryStage) {
        // Set the application title and icon
        primaryStage.setTitle("Games Database App");
        primaryStage.getIcons().add(new Image("file:src/main/resources/img.png")); // Set your unique icon

        // Create the main scene with a text field and button
        VBox root = new VBox();
        TextField searchField = new TextField();
        searchField.setPromptText("Enter game name"); // Placeholder text for the search field
        Button searchButton = new Button("Get Game Info");
        ListView<Game> gameListView = new ListView<>();

        // Set up button action to fetch game info
        searchButton.setOnAction(e -> fetchGameInfo(searchField.getText(), gameListView));

        // Set up click event for gameListView
        gameListView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) {
                Game selectedGame = gameListView.getSelectionModel().getSelectedItem();
                if (selectedGame != null) {
                    showGameDetails(selectedGame, primaryStage);
                }
            }
        });
        // Add components to the root layout
        root.getChildren().addAll(searchField, searchButton, gameListView);
        mainScene = new Scene(root, 800, 600);
        mainScene.getStylesheets().add("style.css"); // Apply your CSS styling
        // Set the scene and show the stage
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    // Function to fetch game information from RAWG API
    private void fetchGameInfo(String query, ListView<Game> gameListView) {
        String apiKey = "45e44215f90e415aa004804cc9a0eaf7"; // Replace with your RAWG API key
        String url = "https://api.rawg.io/api/games?key=" + apiKey + "&page_size=10&search=" + query;

        try {

            // Create and send the HTTP request
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String responseBody = response.body();
            System.out.println(responseBody); // Print response for debugging
            // Parse JSON response
            JSONObject jsonObject = new JSONObject(responseBody);
            JSONArray results;
            // Check if the 'results' key exists
            if (jsonObject.has("results")) {
                results = jsonObject.getJSONArray("results");
            } else {
                System.out.println("No 'results' key found in the response");
                return;
            }
            // Create a list of games to be displayed
            ObservableList<Game> games = FXCollections.observableArrayList();
            for (int i = 0; i < results.length(); i++) {
                JSONObject gameJson = results.getJSONObject(i);
                String name = gameJson.optString("name", "No name available");
                String id = gameJson.optString("id", "No ID available");
                String description = gameJson.optString("description", "No description available");
                String imageUrl = gameJson.optString("background_image", "");

                games.add(new Game(name, id, description, imageUrl));
            }
// Update the ListView with the game list
            gameListView.setItems(games);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Function to show game details on a new scene
    private void showGameDetails(Game game, Stage primaryStage) {
        String apiKey = "45e44215f90e415aa004804cc9a0eaf7"; // Replace with your RAWG API key
        String url = "https://api.rawg.io/api/games/" + game.getId() + "?key=" + apiKey;

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String responseBody = response.body();

            JSONObject jsonObject = new JSONObject(responseBody);
            String name = jsonObject.optString("name", "No name available");
            String releaseDate = jsonObject.optString("released", "Unknown");
            JSONArray genresArray = jsonObject.optJSONArray("genres");
            String genre = "Unknown";
            if (genresArray != null && genresArray.length() > 0) {
                JSONObject genreObject = genresArray.optJSONObject(0);
                if (genreObject != null) {
                    genre = genreObject.optString("name", "Unknown");
                }
            }
            String runtime = jsonObject.optString("playtime", "Unknown");
            String rating = jsonObject.optString("rating", "Unknown");
            String plot = jsonObject.optString("description", "No description available");
            String imageUrl = jsonObject.optString("background_image", ""); // Ensure this is correct

            // Create labels for each piece of information
            Label nameLabel = new Label("Name: " + name);
            Label releaseDateLabel = new Label("Release Date: " + releaseDate);
            Label genreLabel = new Label("Genre: " + genre);
            Label runtimeLabel = new Label("Runtime: " + runtime + " hours");
            Label ratingLabel = new Label("Rating: " + rating + "/100");
            Text plotText = new Text(plot);

            // Set text wrapping for long descriptions
            plotText.setWrappingWidth(600);

            // Create and configure the ImageView
            ImageView gameImage = new ImageView(new Image(imageUrl));
            gameImage.setFitWidth(400); // Adjust as needed
            gameImage.setPreserveRatio(true); // Preserve aspect ratio

            // Create back button
            Button backButton = new Button("Back");
            backButton.setOnAction(e -> primaryStage.setScene(mainScene));

            // Arrange everything in a VBox
            VBox detailsView = new VBox(10, gameImage, nameLabel, releaseDateLabel, genreLabel, runtimeLabel, ratingLabel, plotText, backButton);
            detailsView.setPadding(new Insets(10));
            detailsView.setStyle("-fx-background-color: white; -fx-padding: 20; -fx-spacing: 10;");

            // Create and set the scene
            Scene detailsScene = new Scene(detailsView, 800, 600);
            detailsScene.getStylesheets().add("style.css"); // Apply your CSS styling

            primaryStage.setScene(detailsScene);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}