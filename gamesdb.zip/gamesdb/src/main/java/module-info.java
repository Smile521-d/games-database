module com.example.gamesdb {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.json;
    requires java.net.http;


    opens com.example.gamesdb to javafx.fxml;
    exports com.example.gamesdb;
}