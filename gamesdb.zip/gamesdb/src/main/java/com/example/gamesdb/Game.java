package com.example.gamesdb;

public class Game {
    private final String name;
    private final String id;
    private final String description;
    private final String imageUrl;

    // Constructor
    public Game(String name, String id, String description, String imageUrl) {
        this.name = name;
        this.id = id;
        this.description = description;
        this.imageUrl = imageUrl;
    }
    // Getters
    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    @Override
    public String toString() {
        return name; // This ensures that the ListView shows the game name
    }
}
